 ______   _        ______   ______  _    __
| |  | \ | |      | |  | | | |     | |  / /
| |--| < | |   _  | |__| | | |     | |-< < 
|_|__|_/ |_|__|_| |_|  |_| |_|____ |_|  \_\
                                           
      _   ______   ______  _    __   -  3.5
     | | | |  | | | |     | |  / /         
 _   | | | |__| | | |     | |-< <          
|_|__|_| |_|  |_| |_|____ |_|  \_\         
_________________________________________________
Casino Edition - By Bryan Holland
Release Date: 12/14/2024
WriterBryan@gmail.com
_________________________________________________
Readme: 

	Make sure to unzip the file into a folder. On the first play, two files will be generated to keep track of your "Fictional Bank Account" along with your User Name. This allows for multiple people to play on the same system and have their own accounts. You can leave the game and come back later and your money will still be there (If you didn't lose of course). 

Rules of Blackjack: 

    Try to get as close to 21 without going over.
    Rules:
    - Kings, Queens, and Jacks are worth 10 points.
    - Aces are worth 1 or 11 points.
    - Cards 2 through 10 are worth their face value.
    - (H)it to take another card.
    - (S)tand to stop taking cards.
    - On your first play, you can (D)ouble down to increase your bet.

	You can view the entire history of your betting, your money, your wins and losses in order to best strategize your play style and your ability to beat the house! I know this game looks old but I'm a brand new programmer and this software is brand new despite being designed in such an old-school way. As I learn how to program, you'll see more software from me and it will get better over time! For now though, just think of this style of gaming as a fun throwback to the 80's before Graphical User Interfaces were a thing! Feel free to drop me a line with the provided e-mail and let me know what you think. I'll be happy to return my correspondence and let you know if I've developed anything new (or even newer looking). 

	Good luck! 
	- Bry! 